import 'package:lab4_tutorial1/lab4_tutorial1.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
