import 'package:lab5_tutorial1/lab5_tutorial1.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
