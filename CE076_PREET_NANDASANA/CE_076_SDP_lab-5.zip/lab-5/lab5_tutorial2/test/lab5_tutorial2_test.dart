import 'package:lab5_tutorial2/lab5_tutorial2.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
